<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pegawai_model extends CI_Model {

	// Load database
	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	// Listing semua pegawai
	public function listing()
	{
		$this->db->select('*');
		$this->db->from('pegawai');
		$this->db->order_by('urutan','ASC');
		$query = $this->db->get();
		return $query->result();
	}

	// Detail semua pegawai
	public function detail($id_pegawai)
	{
		$this->db->select('*');
		$this->db->from('pegawai');
		$this->db->where('id_pegawai',$id_pegawai); // Where
		$this->db->order_by('urutan','ASC');
		$query = $this->db->get();
		return $query->row(); // single data
	}

	// Tambah pegawai
	public function tambah($data)
	{
		$this->db->insert('pegawai',$data);
	}

	// Edit pegawai
	public function edit($data)
	{
		$this->db->where('id_pegawai',$data['id_pegawai']);
		$this->db->update('pegawai',$data);
	}

	// Delete pegawai
	public function delete($data)
	{
		$this->db->where('id_pegawai',$data['id_pegawai']);
		$this->db->delete('pegawai',$data);
	}
}

/* End of file Pegawai_model.php */
/* Location: ./application/models/Pegawai_model.php */