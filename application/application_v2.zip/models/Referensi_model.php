<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Referensi_model extends CI_Model {

	public function __construct()
	{
		parent::__construct();
		$this->load->database();
	}

	// Listing
	public function listing_agama()
	{
		$this->db->select('*');
		$this->db->from('agama');
		$this->db->order_by('id_agama','ASC');
		$query = $this->db->get();
		return $query->result();
	}

	// Listing
	public function listing_jenis_pegawai()
	{
		$this->db->select('*');
		$this->db->from('jenis_pegawai');
		$this->db->order_by('id_jenis_pegawai','ASC');
		$query = $this->db->get();
		return $query->result();
	}

	// Listing
	public function listing_provinsi()
	{
		$this->db->select('*');
		$this->db->from('provinsi');
		$this->db->order_by('id_prov','ASC');
		$query = $this->db->get();
		return $query->result();
	}

	// Listing
	public function listing_kabupaten()
	{
		$this->db->select('*');
		$this->db->from('kabupaten');
		$this->db->order_by('id_kab','ASC');
		$query = $this->db->get();
		return $query->result();
	}

	// Listing
	public function listing_kecamatan()
	{
		$this->db->select('*');
		$this->db->from('kecamatan');
		$this->db->order_by('id_kec','ASC');
		$query = $this->db->get();
		return $query->result();
	}

}

/* End of file Referensi_model.php */
/* Location: ./application/models/Referensi_model.php */