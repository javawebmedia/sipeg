<!-- Left side column. contains the logo and sidebar -->
  <aside class="main-sidebar">
    <!-- sidebar: style can be found in sidebar.less -->
    <section class="sidebar">
     
      <!-- sidebar menu: : style can be found in sidebar.less -->
      <ul class="sidebar-menu" data-widget="tree">
        <li class="header">MAIN NAVIGATION</li>

        <!-- DATA PEGAWAI -->
        <li class="treeview">
          <a href="#">
            <i class="fa fa-users"></i> <span>DATA PEGAWAI</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url('admin/pegawai') ?>"><i class="fa fa-circle-o"></i> Data Pegawai</a></li>
            <li><a href="<?php echo base_url('admin/pegawai/tambah') ?>"><i class="fa fa-circle-o"></i> Tambah Pegawai</a></li>
          </ul>
        </li>

        <!-- DATA REFERENSI -->
        <li class="treeview">
          <a href="#">
            <i class="fa fa-table"></i> <span>REFERENSI DATA</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url('admin/referensi/agama') ?>"><i class="fa fa-circle-o"></i> Data Agama</a></li>
            <li><a href="<?php echo base_url('admin/referensi/provinsi') ?>"><i class="fa fa-circle-o"></i> Data Provinsi</a></li>
            <li><a href="<?php echo base_url('admin/referensi/kabupaten') ?>"><i class="fa fa-circle-o"></i> Data Kabupaten/Kota</a></li>
            <li><a href="<?php echo base_url('admin/referensi/kecamatan') ?>"><i class="fa fa-circle-o"></i> Data Kecamatan</a></li>
            <li><a href="<?php echo base_url('admin/referensi/jenis') ?>"><i class="fa fa-circle-o"></i> Data Jenis Pegawai</a></li>
          </ul>
        </li>
        
      </ul>
    </section>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
        <?php echo $title ?>
      </h1>
      <ol class="breadcrumb">
        <li><a href="#"><i class="fa fa-dashboard"></i> Home</a></li>
        <li class="active"><?php echo $title ?></li>
      </ol>
    </section>

    <!-- Main content -->
    <section class="content">
      <!-- Info boxes -->
      <div class="row">
        <div class="col-xs-12">
        <div class="box">
          <div class="box-body" style="min-height: 500px;">
