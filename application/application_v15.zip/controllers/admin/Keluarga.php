<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Keluarga extends CI_Controller {

	// Load model
	public function __construct()
	{
		parent::__construct();
		$this->load->model('pegawai_model');
		$this->load->model('pendidikan_model');
		$this->load->model('referensi_model');
		$this->load->model('hubkel_model');
		$this->load->model('keluarga_model');
	}

	// Main page
	public function index()
	{
		$keluarga 	= $this->keluarga_model->listing();
		$jumlah 	= count($keluarga);

		$data = array(	'title'		=> 'Data Keluarga Pegawai ('.$jumlah.')',
						'keluarga'	=> $keluarga,
						'isi'		=> 'admin/keluarga/list'
						);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}

	// Tambah Pegawai
	public function tambah()
	{
		$pegawai 	= $this->pegawai_model->listing();
		$jumlah 	= count($pegawai);

		$data = array(	'title'		=> 'Data Pegawai ('.$jumlah.')',
						'pegawai'	=> $pegawai,
						'isi'		=> 'admin/keluarga/list_pegawai'
						);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}

	// Kelola keluarga pegawai
	public function pegawai($id_pegawai)
	{
		$keluarga 	= $this->keluarga_model->pegawai($id_pegawai);
		$jumlah 	= count($keluarga);
		$pegawai 	= $this->pegawai_model->detail($id_pegawai);

		$data = array(	'title'		=> 'Keluarga: '.$pegawai->nama_lengkap.' ('.$jumlah.')',
						'keluarga'	=> $keluarga,
						'pegawai'	=> $pegawai,
						'isi'		=> 'admin/keluarga/pegawai'
						);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}

}

/* End of file Keluarga.php */
/* Location: ./application/controllers/admin/Keluarga.php */