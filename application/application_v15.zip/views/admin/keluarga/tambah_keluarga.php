<button class="btn btn-success btn-lg" data-toggle="modal" data-target="#Tambah">
    <i class="fa fa-plus"></i> Tambah Anggota Keluarga Baru
</button>

<div class="modal fade" id="Tambah" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
<div class="modal-dialog modal-lg">

<?php 
echo form_open_multipart(base_url('admin/keluarga/pegawai/'.$pegawai->id_pegawai)); 
?>

<div class="modal-content">
<div class="modal-header">
    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
    <h4 class="modal-title" id="myModalLabel">Tambah data?</h4>
</div>
<div class="modal-body">
    
    <p class="alert alert-danger">Yakin ingin menghapus data ini?</p>

</div>
<div class="modal-footer">
    <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
    
    

</div>
</div>

<?php echo form_close(); ?>

</div>
</div>
