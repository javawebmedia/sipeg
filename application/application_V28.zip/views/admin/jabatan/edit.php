<script>
  $('#Tambah').on('show', function () {
    $.fn.modal.Constructor.prototype.enforceFocus = function () { };
});

</script>


<?php 
echo form_open_multipart(base_url('admin/jabatan/edit/'.$jabatan->id_jabatan)); 
?>


<div class="col-md-6">

	<div class="form-group">
		<label>Nama Jabatan/Pelatihan</label>
		<input type="text" name="nama_jabatan" class="form-control" placeholder="Nama Jabatan/Pelatihan" value="<?php echo $jabatan->nama_jabatan ?>" required>
	</div>

	<div class="form-group">
		<label>Nama Institusi Jabatan/Penyelenggara</label>
		<input type="text" name="nama_institusi" class="form-control" placeholder="Nama Institusi Jabatan/Penyelenggara" value="<?php echo $jabatan->nama_institusi ?>">
	</div>

	<div class="form-group">
		<label>Jenis Jabatan</label>
		<select name="id_jenis_jabatan" class="form-control">

			<?php foreach($jenis_jabatan as $jenis_jabatan) { ?>
			<option value="<?php echo $jenis_jabatan->id_jenis_jabatan ?>" 
			<?php if($jenis_jabatan->id_jenis_jabatan==$jabatan->id_jenis_jabatan) { echo "selected"; } ?>
				>
				<?php echo $jenis_jabatan->nama_jenis_jabatan ?>
			</option>
			<?php } ?>
		</select>
	</div>

	<div class="form-group">
		<label>Jenjang Jabatan</label>
		<select name="id_jenjang" class="form-control">

			<option value="">Jenjang Jabatan</option>
			<?php foreach($jenjang as $jenjang) { ?>
			<option value="<?php echo $jenjang->id_jenjang ?>" 
			<?php if($jenjang->id_jenjang==$jabatan->id_jenjang) { echo "selected"; } ?>
				>
				<?php echo $jenjang->nama_jenjang ?>
			</option>
			<?php } ?>
		</select>
	</div>

</div>

<div class="col-md-6">

	
	<div class="row">

		<div class="col-md-6">
			<div class="form-group">
				<label>Tahun Lulus</label>
				<input type="number" name="tahun" class="form-control" placeholder="Tahun Lulus" value="<?php echo $jabatan->tahun ?>" required>
			</div>
		</div>

		<div class="col-md-6">
			<div class="form-group">
				<label>Tanggal Ijazah/Sertifikat</label>
				<input type="text" name="tanggal_ijazah" class="form-control datepicker" placeholder="Tanggal Ijazah/Sertifikat" value="<?php echo $jabatan->tanggal_ijazah ?>">
			</div>

		</div>

	</div>

	

	<div class="form-group">
		<label>Nomor Ijazah/Sertifikat</label>
		<input type="text" name="nomor_ijazah" class="form-control" placeholder="Nomor Ijazah/Sertifikat" value="<?php echo $jabatan->nomor_ijazah ?>">
	</div>


	<div class="form-group">
		<label>Keterangan</label>
		<textarea name="keterangan" placeholder="Keterangan" class="form-control"><?php echo $jabatan->keterangan ?></textarea>
	</div>

	<div class="form-group">
		<label>Upload File Ijazah/Sertifikat</label>
		<input type="file" name="gambar" class="form-control" placeholder="Upload File Ijazah/Sertifikat">
		<small class="text-danger">Extensi: doc, docx, pdf, zip, jpg, png, gif, jpeg</small>
	</div>

<div class="form-group">
    <button type="submit" class="btn btn-success btn-lg">
    	<i class="fa fa-save"></i> Simpan Data
    </button>
    
    <button type="reset" class="btn btn-warning btn-lg">
    	<i class="fa fa-backward"></i> Reset
    </button>

    

</div>
</div>

<?php echo form_close(); ?>


