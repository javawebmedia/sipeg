<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Profil extends CI_Controller {

	// Load model
	public function __construct()
	{
		parent::__construct();
		$this->load->model('pegawai_model');
		$this->load->model('referensi_model');
		// Load helper string
		$this->load->helper('string');
	}

	// Main page profil
	public function index()
	{
		$id_pegawai = $this->session->userdata('id_pegawai');
		$pegawai 	= $this->pegawai_model->detail($id_pegawai);

		$provinsi 	= $this->referensi_model->listing_provinsi();
		$kota 		= $this->referensi_model->listing_kabupaten();
		$jenis 		= $this->referensi_model->listing_jenis_pegawai();
		$agama 		= $this->referensi_model->listing_agama();

		// Validasi
		$valid = $this->form_validation;

		$valid->set_rules('nama_lengkap','Nama','required',
			array(	'required'		=> '%s harus diisi'));

		$valid->set_rules('nrk','NRK','required',
			array(	'required'		=> '%s harus diisi'));

		$valid->set_rules('nip','NIP','required',
			array(	'required'		=> '%s harus diisi'));

		if($valid->run()=== FALSE) {
		// End validasi

		$data = array(	'title'		=> 'Perbaharui Profil: '.$pegawai->nama_lengkap,
						'pegawai'	=> $pegawai, // Data pegawai yg diedit
						'provinsi'	=> $provinsi,
						'kota'		=> $kota,
						'jenis'		=> $jenis,
						'agama'		=> $agama,
						'isi'		=> 'admin/profil/list'
					);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
		// Validasi lolos dan masuk database
		}else{
			$i 	= $this->input;
			$data = array(	'id_pegawai'		=> $id_pegawai, // Dari URL
							//'id_jenis_pegawai'	=> $i->post('id_jenis_pegawai'),
							'tmt_cpns'			=> $i->post('tmt_cpns'),
							'tmt_pns'			=> $i->post('tmt_pns'),
							'updated_by'		=> $this->session->userdata('id_pegawai'),
							//'nip'				=> $i->post('nip'),
							//'nrk'				=> $i->post('nrk'),
							'nama_lengkap'		=> $i->post('nama_lengkap'),
							'gelar_depan'		=> $i->post('gelar_depan'),
							'gelar_belakang'	=> $i->post('gelar_belakang'),
							'tempat_lahir'		=> $i->post('tempat_lahir'),
							'tanggal_lahir'		=> $i->post('tanggal_lahir'),
							'jenis_kelamin'		=> $i->post('jenis_kelamin'),
							'agama'				=> $i->post('agama'),
							'status_kawin'		=> $i->post('status_kawin'),
							'provinsi'			=> $i->post('provinsi'),
							'kota'				=> $i->post('kota'),
							'kecamatan'			=> $i->post('kecamatan'),
							'kelurahan'			=> $i->post('kelurahan'),
							'alamat'			=> $i->post('alamat'),
							'telepon'			=> $i->post('telepon'),
							'email'				=> $i->post('email'),
							'nik'				=> $i->post('nik'),
							'npwp'				=> $i->post('npwp'),
							'nomor_bpjs'		=> $i->post('nomor_bpjs'),
							'nomor_rekening'	=> $i->post('nomor_rekening'),
							'nama_bank'			=> $i->post('nama_bank'),
							//'akses_level'		=> $i->post('akses_level'),
							'keterangan'		=> $i->post('keterangan'),
							'urutan'			=> $i->post('urutan')
						);
			$this->pegawai_model->edit($data);
			$this->session->set_flashdata('sukses','Profil telah diperbaharui');
			redirect(base_url('admin/profil'),'refresh');
		}
		// End masuk database
	}

	// Ganti Password 
	public function password()
	{
		$id_pegawai = $this->session->userdata('id_pegawai');
		$pegawai 	= $this->pegawai_model->detail($id_pegawai);

		// Validasi
		$valid = $this->form_validation;

		$valid->set_rules('password','Password','required|min_length[6]|max_length[32]|trim',
			array(	'required'		=> '%s harus diisi',
					'min_length'	=> '%s minmal 6 karakter',
					'max_length'	=> '%s maksimal 32 karakter'
					));

		$valid->set_rules('konfirmasi_password','Konfirmasi Password','required|matches[password]',
			array(	'required'		=> '%s harus diisi',
					'matches'		=> '%s tidak sama'
				));

		if($valid->run()=== FALSE) {
		// End validasi

		$data = array(	'title'		=> 'Ganti Password: '.$pegawai->nama_lengkap,
						'pegawai'	=> $pegawai, // Data pegawai yg diedit
						'isi'		=> 'admin/profil/password'
					);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
		// Validasi lolos dan masuk database
		}else{
			$i 	= $this->input;
			$data = array(	'id_pegawai'	=> $id_pegawai, // Dari URL
							'password'		=> sha1($i->post('password'))
						);
			$this->pegawai_model->edit($data);
			$this->session->set_flashdata('sukses','Password berhasil diganti');
			redirect(base_url('admin/profil/password'),'refresh');
		}
		// End masuk database
	}

}

/* End of file Profil.php */
/* Location: ./application/controllers/admin/Profil.php */