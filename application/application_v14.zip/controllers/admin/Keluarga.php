<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Keluarga extends CI_Controller {

	// Load model
	public function __construct()
	{
		parent::__construct();
		$this->load->model('pegawai_model');
		$this->load->model('pendidikan_model');
		$this->load->model('referensi_model');
		$this->load->model('hubkel_model');
		$this->load->model('keluarga_model');
	}

	// Main page
	public function index()
	{
		$keluarga 	= $this->keluarga_model->listing();
		$jumlah 	= count($keluarga);

		$data = array(	'title'		=> 'Data Keluarga Pegawai ('.$jumlah.')',
						'keluarga'	=> $keluarga,
						'isi'		=> 'admin/keluarga/list'
						);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}

}

/* End of file Keluarga.php */
/* Location: ./application/controllers/admin/Keluarga.php */