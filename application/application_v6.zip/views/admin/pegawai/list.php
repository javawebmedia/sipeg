<p>
	<a href="<?php echo base_url('admin/pegawai/tambah') ?>" title="Tambah Pegawai" class="btn btn-success btn-lg">
		<i class="fa fa-plus"></i> Tambah Baru
	</a>
</p>

<table id="example1" class="table table-bordered table-striped">
<thead>
<tr>
  <th>NIP</th>
  <th>NAMA LENGKAP</th>
  <th>TTL</th>
  <th>L/P</th>
  <th width="20%">ACTION</th>
</tr>
</thead>
<tbody>

<?php $no = 1; foreach($pegawai as $pegawai){ ?>

<tr>
  <td><?php echo $pegawai->nip ?></td>
  <td><?php echo $pegawai->nama_lengkap ?></td>
  <td><?php echo $pegawai->tempat_lahir ?>, <?php echo date('d-m-Y',strtotime($pegawai->tanggal_lahir)) ?></td>
  <td><?php echo $pegawai->jenis_kelamin ?></td>
  <td>

    <?php include('akses.php') ?>

    <a href="<?php echo base_url('admin/pegawai/edit/'.$pegawai->id_pegawai) ?>" class="btn btn-warning btn-xs"><i class="fa fa-edit"></i> Edit</a>

    <?php include('delete.php') ?>

  </td>
</tr>

<?php $no++; } ?>

</tbody>
</table>