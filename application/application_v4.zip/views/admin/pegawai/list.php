<p>
	<a href="<?php echo base_url('admin/pegawai/tambah') ?>" title="Tambah Pegawai" class="btn btn-success btn-lg">
		<i class="fa fa-plus"></i> Tambah Baru
	</a>
</p>

<table id="example1" class="table table-bordered table-striped">
<thead>
<tr>
  <th>NO</th>
  <th>NAMA LENGKAP</th>
  <th>TTL</th>
  <th>L/P</th>
  <th>ACTION</th>
</tr>
</thead>
<tbody>

<?php $no = 1; foreach($pegawai as $pegawai){ ?>

<tr>
  <td><?php echo $no ?></td>
  <td><?php echo $pegawai->nama_lengkap ?></td>
  <td><?php echo $pegawai->tempat_lahir ?></td>
  <td><?php echo $pegawai->jenis_kelamin ?></td>
  <td></td>
</tr>

<?php $no++; } ?>

</tbody>
</table>