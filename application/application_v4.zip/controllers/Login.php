<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller {

	// Halaman login
	public function index()
	{
		$data = array( 'title'		=> 'Login Administrator');
		$this->load->view('admin/login_view', $data, FALSE);
	}

	// Lupa password
	public function lupa()
	{
		$data = array( 'title'		=> 'Lupa password');
		$this->load->view('admin/lupa', $data, FALSE);
	}

	// Reset password
	public function reset()
	{
		$data = array( 'title'		=> 'Reset password');
		$this->load->view('admin/reset', $data, FALSE);
	}
}

/* End of file Login.php */
/* Location: ./application/controllers/Login.php */