<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Pegawai extends CI_Controller {

	// Load database
	public function __construct()
	{
		parent::__construct();
		$this->load->model('pegawai_model');
		$this->load->model('referensi_model');
	}

	// Main page pegawai
	public function index()
	{
		$pegawai 	= $this->pegawai_model->listing();
		$jumlah		= count($pegawai);

		$data = array(	'title'		=> 'Data Pegawai ('.$jumlah.')',
						'pegawai'	=> $pegawai,
						'isi'		=> 'admin/pegawai/list'
					);
		$this->load->view('admin/layout/wrapper', $data, FALSE);
	}

	// Tambah pegawai baru
	public function tambah()
	{
		$provinsi 	= $this->referensi_model->listing_provinsi();
		$kota 		= $this->referensi_model->listing_kabupaten();
		$jenis 		= $this->referensi_model->listing_jenis_pegawai();

		$data = array(	'title'		=> 'Tambah Pegawai Baru',
						'provinsi'	=> $provinsi,
						'kota'		=> $kota,
						'jenis'		=> $jenis,
						'isi'		=> 'admin/pegawai/tambah'
					);
		$this->load->view('admin/layout/wrapper', $data, FALSE);

	}

}

/* End of file Pegawai.php */
/* Location: ./application/controllers/admin/Pegawai.php */