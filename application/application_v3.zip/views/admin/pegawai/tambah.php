<?php 
echo form_open(base_url('admin/pegawai/tambah'));
?>

<div class="col-md-6">
	<div class="form-group form-group-lg has-error">
		<label>Nama lengkap</label>
		<input type="text" name="nama_lengkap" class="form-control" placeholder="Nama lengkap" value="<?php echo set_value('nama_lengkap') ?>" required>
	</div>
</div>

<div class="col-md-3">
	<div class="form-group form-group-lg has-error">
		<label>NRK</label>
		<input type="number" name="nrk" class="form-control" placeholder="NRK" value="<?php echo set_value('nrk') ?>" required>
	</div>
</div>	

<div class="col-md-3">
	<div class="form-group form-group-lg has-error">
		<label>NIP</label>
		<input type="number" name="nip" class="form-control" placeholder="NIP" value="<?php echo set_value('nip') ?>" required>
	</div>
</div>

<div class="col-md-3">
	<div class="form-group">
		<label>Jenis Pegawai</label>
		<select name="id_jenis_pegawai" class="form-control">

			<?php foreach($jenis as $jenis) { ?>
			<option value="<?php echo $jenis->id_jenis_pegawai ?>">
				<?php echo $jenis->nama_jenis_pegawai ?>
			</option>
			<?php } ?>

		</select>
	</div>
</div>

<div class="col-md-3">
	<div class="form-group">
		<label>Jenis Kelamin</label>
		<select name="jenis_kelamin" class="form-control">
			<option value="P">Perempuan</option>}
			<option value="L">Laki-laki</option>}
		</select>
	</div>
</div>		

<div class="col-md-3">
	<div class="form-group">
		<label>Gelar depan (mis: dr, Dr)</label>
		<input type="text" name="gelar_depan" class="form-control" placeholder="Gelar depan (mis: dr, Dr)" value="<?php echo set_value('gelar_depan') ?>">
	</div>
</div>

<div class="col-md-3">
	<div class="form-group">
		<label>Gelar belakang (mis: Sp.OG, S.Pd)</label>
		<input type="text" name="gelar_belakang" class="form-control" placeholder="Gelar belakang (mis: Sp.OG, S.Pd)" value="<?php echo set_value('gelar_belakang') ?>">
	</div>
</div>	

<div class="col-md-3">
	<div class="form-group">
		<label>Tempat lahir</label>
		<input type="text" name="tempat_lahir" class="form-control" placeholder="Tempat lahir" value="<?php echo set_value('tempat_lahir') ?>">
	</div>
</div>

<div class="col-md-3">
	<div class="form-group">
		<label>Tanggal lahir</label>
		<input type="text" name="tanggal_lahir" class="form-control datepicker" placeholder="YYYY-MM-DD" value="<?php echo set_value('tanggal_lahir') ?>" data-date-format="yyyy-mm-dd">
	</div>
</div>


<?php 
echo form_close();
?>