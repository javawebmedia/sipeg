<p><a href="<?php echo base_url('admin/pendidikan/tambah') ?>" class="btn btn-primary">
<i class="fa fa-plus"></i> Kelola dan Tambah Data Pendidikan</a></p>


<table class="table table-striped table-bordered table-hover" id="example1">
<thead>
<tr>
    <th>#</th>
    <th>Nama Pegawai</th>
    <th>Nama Pendidikan</th>
    <th>Status</th>
    <th>L/P</th>
    <th>TTL</th>
    <th>Pendidikan</th>
    <th>Action</th>
</tr>
</thead>
<tbody>

<?php $i=1; foreach($pendidikan as $pendidikan) { ?>

<tr class="odd gradeX">
    <td><?php echo $i ?></td>
    <td>
      <a href="<?php echo base_url('admin/pendidikan/pegawai/'.$pendidikan->id_pegawai) ?>">
      <?php echo $pendidikan->nama_pegawai ?>
      </a>  
    </td>
    <td><?php echo $pendidikan->nama_lengkap ?></td>
    <td><?php echo $pendidikan->nama_jenis_pendidikan ?></td>
    <td><?php echo $pendidikan->jenis_kelamin ?></td>
    <td><?php echo $pendidikan->tempat_lahir ?>, <?php echo date('d-m-Y',strtotime($pendidikan->tanggal_lahir)) ?></td>
    <td><?php echo $pendidikan->nama_jenjang ?></td>
    <td>
      <a href="<?php echo base_url('admin/pendidikan/read/'.$pendidikan->id_pendidikan) ?>" 
      class="btn btn-success btn-xs" target="_blank"><i class="fa fa-eye"></i></a>

      <a href="<?php echo base_url('admin/pendidikan/cetak/'.$pendidikan->id_pendidikan) ?>" 
      class="btn btn-info btn-xs" target="_blank"><i class="fa fa-print"></i></a>

      <a href="<?php echo base_url('admin/pendidikan/edit/'.$pendidikan->id_pendidikan) ?>" 
      class="btn btn-warning btn-xs"><i class="fa fa-edit"></i></a>

      <?php include('delete.php'); ?>

    </td>
</tr>

<?php $i++; } ?>

</tbody>
</table>